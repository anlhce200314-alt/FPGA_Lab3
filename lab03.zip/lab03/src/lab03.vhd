library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity lab03 is
    port (
        clk : in  std_logic;
        bt  : in  std_logic;
        led : out std_logic
    );
end entity lab03;

architecture logic of lab03 is
    signal current_sample  : std_logic := '1';
    signal previous_sample : std_logic := '1';
    signal led_state       : std_logic := '0';
begin

    process(clk)
    begin
        if rising_edge(clk) then
            previous_sample <= current_sample;
            current_sample  <= bt;

            if (previous_sample = '0' and current_sample = '1') then
                led_state <= not led_state;
            end if;
        end if;
    end process;

    led <= led_state;

end architecture logic;
