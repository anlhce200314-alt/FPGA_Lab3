`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
ePZmL1dlzWhqGnXMrxhzKPjFvpAbY7eN6YffQGi9geM8hsBseKbmdFUaU57uO9sC0QNNb/1arN4S
/Ru2D5cG/Cn3Jb0aw7nSFzIS5a2Cvd613hdDTJNgjkDgaxYJxQI82s15/8aH+8d+jhruIzuaAdEv
y52nvW/NIYNZtFRo3Z/2KElrDOCRdpaMDr/tIuednytiqnY3i3mtjmag1DEVYGKsaymlzC8xPg/M
mon9xDX3KyJ2MHKoL/JTYSf8vXkrTN6Yd+TI4wE0gvawynNRVZrFJGm5W10JtjBxIUDqEvbsZv+5
/vmZpBAVFkbrZ5X1+Jdys5wMmrnoU1QVNIvVEw==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=432)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
Ql23HEO6wd2l5Y7NDzoZy932S4zhMeot4TViKHQofX+SlUAHc5uGPe7MPxJmrJm3Z4wOP5dl/mDm
rG1S89WKWLWrFISZb8Zl+HBMri5MUhYt9qMeZhbcQKk72osPpYOc78/sSs736uq006t/xmL93G5v
gM51Y+4qH4TpCKo/Dk2SPXZ0UzuQl987ftPQojtSNLVx3APGPRsDPlfJ40mHHsfDe1um9KNBYyXg
yrk5IOJ+KQjZW1kRGKzTaHQUp3czgFm0jKTVymkkGvxWeMswX9LHVu76RFchh90OJoY07avOFD44
/bC9LiRP1Lx+2BE2TyOiJE583r68EmU5BTmK3EkG9JdNSm1J6q+GilVw1D+ltsGWa/DQ+uWn64i+
4dTy4+bAWHf/OD9Uu/flEs8dtpQhKm5KZhS4JWHWF0olHEeNBfXF19jO7n7V2W8i2qHBFwHI6GUn
uF2Dx2DsTaC5yhbZTcDsOns2UTxmyTEroNm87BRxIkdB6tnfZo8wYOwpUwyca4Z7q1F/81HOseqb
a6bfA9nhxv6TfIEVcnFPqEfC0cYvYlA30pQ1jE3czPOs
`pragma protect end_protected
