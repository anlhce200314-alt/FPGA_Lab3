library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity lab03_tb is
end entity lab03_tb;

architecture sim of lab03_tb is
    constant CLK_PERIOD : time := 20 ns;
    
    signal clk : STD_LOGIC := '0';
    signal bt  : STD_LOGIC := '1';
    signal led : STD_LOGIC;
begin
    DUT: entity work.lab03
        port map (
            clk => clk,
            bt  => bt,
            led => led
        );

    clk_process: process
    begin
        clk <= '0';
        wait for CLK_PERIOD / 2;
        clk <= '1';
        wait for CLK_PERIOD / 2;
    end process;

    stimulus: process
    begin
        bt <= '1';
        wait for 100 ns;
        assert led = '0'
            report "T0 FAILED: Initial LED state expected 0"
            severity error;
        bt <= '0';
        wait for 220 ns;
        assert led = '0'
            report "T1 FAILED: LED must not toggle while switch is held down"
            severity error;

        bt <= '1';
        wait for 80 ns;
        assert led = '1'
            report "T2 FAILED: LED must toggle ON after first release"
            severity error;

        wait for 200 ns;
        assert led = '1'
            report "T3 FAILED: LED changed without a new release event"
            severity error;

        bt <= '0';
        wait for 240 ns;
        assert led = '1'
            report "T4 FAILED: Press must not toggle LED"
            severity error;

        bt <= '1';
        wait for 80 ns;
        assert led = '0'
            report "T5 FAILED: LED must toggle OFF after second release"
            severity error;

        bt <= '0';
        wait for 80 ns;
        bt <= '1';
        wait for 80 ns;
        assert led = '1'
            report "T6 FAILED: Fast release #1 did not toggle LED"
            severity error;

        bt <= '0';
        wait for 80 ns;
        bt <= '1';
        wait for 80 ns;
        assert led = '0'
            report "T7 FAILED: Fast release #2 did not toggle LED"
            severity error;

        report "LAB03: ALL SELF-CHECKING TESTS PASSED"
            severity note;
        wait;
    end process stimulus;

end architecture sim;